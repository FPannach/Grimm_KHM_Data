# -*- coding: utf-8 -*-
import re
import os 


flist = os.listdir('C:\\Franzi\\Arbeit\\ETrap\\1812')
color = re.compile("schwarz", re.IGNORECASE)
fnew = open("Black.txt", "w")
fnew.write("Titel\tSchwarz\n")

for fname in flist :
	fcontents = open(fname,"r").read()

	fone=fcontents.replace("\n","")
	match = re.search(color, fone)

	if match  : 
		fnew.write(fname+"\tx\n")
	else :
		fnew.write(fname+"\tnull\n")


