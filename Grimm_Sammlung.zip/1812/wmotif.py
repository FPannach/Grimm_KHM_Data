# -*- coding: utf-8-*-

import re
import os 
import codecs

flist = os.listdir('C:\\Franzi\\Arbeit\\ETrap\\1812')
color = re.compile('wei(ss|�)', re.IGNORECASE)

#color = re.compile('weiss', re.IGNORECASE)


fnew = open("White.txt", "w")
fnew.write(u"Titel\tWeiss\n")



for fname in flist :
	fcontents = codecs.open(fname,"r", encoding='Latin-1').read()

	fone=fcontents.replace("\n","")
	match = re.search(color, fcontents)

	if match : 
		fnew.write(fname+"\tx\n")
	else :
		fnew.write(fname+"\tnull\n")

