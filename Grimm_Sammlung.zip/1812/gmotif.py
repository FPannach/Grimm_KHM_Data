# -*- coding: utf-8- -*-

import re
import os 

flist = os.listdir('C:\\Franzi\\Arbeit\\ETrap\\1812')
color = re.compile(u"grün", re.IGNORECASE)
fnew = open("Grün.txt", "w")
fnew.write(u"Titel\tGrün\n")

for fname in flist :
	fcontents = open(fname,"r").read()


	fone=fcontents.replace("\n","")
	match = re.search(color, fone)

	if match  : 
		fnew.write(fname+"\tx\n")
	else :
		fnew.write(fname+"\tnull\n")


